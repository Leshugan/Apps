package leshugan.ma;

import androidx.core.content.FileProvider;

// Отдельный подкласс, чтобы НЕ конфликтовать с FileProvider, который регистрирует Capacitor
// (иначе authority «слипается» с провайдером Capacitor).
public class AppsFileProvider extends FileProvider {
}
