package leshugan.ma;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.Window;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    /* ===== Список приложений (без иконок — мгновенно) ===== */
    @PluginMethod
    public void listApps(PluginCall call) {
        new Thread(() -> {
            try {
                PackageManager pm = getContext().getPackageManager();
                List<PackageInfo> pkgs = pm.getInstalledPackages(0);
                JSArray arr = new JSArray();
                for (PackageInfo pi : pkgs) {
                    ApplicationInfo ai = pi.applicationInfo;
                    if (ai == null) continue;
                    JSObject o = new JSObject();
                    o.put("pkg", pi.packageName);
                    String label;
                    try { label = pm.getApplicationLabel(ai).toString(); } catch (Exception e) { label = pi.packageName; }
                    o.put("label", label);
                    o.put("ver", pi.versionName == null ? "" : pi.versionName);
                    long vc = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                    o.put("vc", vc);
                    boolean sys = (ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                    o.put("sys", sys);
                    long size = 0;
                    boolean split = false;
                    try {
                        if (ai.sourceDir != null) size += new File(ai.sourceDir).length();
                        String[] sp = ai.splitSourceDirs;
                        if (sp != null && sp.length > 0) { split = true; for (String s : sp) size += new File(s).length(); }
                    } catch (Exception ignored) {}
                    o.put("size", size);
                    o.put("split", split);
                    o.put("up", pi.lastUpdateTime); // отслеживание обновлений: иконка перечитывается по времени обновления пакета
                    o.put("en", ai.enabled); // false = приложение отключено (заморожено)
                    arr.put(o);
                }
                JSObject ret = new JSObject();
                ret.put("apps", arr);
                call.resolve(ret);
            } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    /* ===== Иконки: пишутся PNG в filesDir/icons, возвращаются пути (JS показывает через convertFileSrc) ===== */
    @PluginMethod
    public void ensureIcons(PluginCall call) {
        JSArray items = call.getArray("items");
        if (items == null) { call.reject("no items"); return; }
        new Thread(() -> {
            try {
                PackageManager pm = getContext().getPackageManager();
                File dir = new File(getContext().getFilesDir(), "icons");
                dir.mkdirs();
                JSObject icons = new JSObject();
                for (int i = 0; i < items.length(); i++) {
                    try {
                        JSONObject it = items.getJSONObject(i);
                        String p = it.getString("p");
                        long v = it.optLong("v", 0);
                        String base = sanitize(p) + "_";
                        File f = new File(dir, base + v + ".png");
                        if (!f.exists()) {
                            // пакет обновился — старые иконки этого пакета больше не нужны
                            File[] all = dir.listFiles();
                            if (all != null) for (File o_ : all) { if (o_.getName().startsWith(base) && !o_.getName().equals(f.getName())) { try { o_.delete(); } catch (Exception ignored) {} } }
                            Drawable d = pm.getApplicationIcon(p);
                            Bitmap b = drawableToBitmap(d);
                            if (b != null) {
                                int mx = Math.max(b.getWidth(), b.getHeight());
                                if (mx > 144) {
                                    float sc = 144f / mx;
                                    b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
                                }
                                FileOutputStream out = new FileOutputStream(f);
                                b.compress(Bitmap.CompressFormat.PNG, 100, out);
                                out.close();
                            }
                        }
                        if (f.exists()) icons.put(p, f.getAbsolutePath());
                    } catch (Exception ignored) {}
                }
                JSObject ret = new JSObject();
                ret.put("icons", icons);
                call.resolve(ret);
            } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    /* ===== Извлечь APK в Загрузки (split → .apks-архив) ===== */
    @PluginMethod
    public void extractApk(PluginCall call) {
        String pkg = call.getString("pkg");
        if (pkg == null) { call.reject("no pkg"); return; }
        new Thread(() -> {
            try {
                PackageManager pm = getContext().getPackageManager();
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                PackageInfo pi = pm.getPackageInfo(pkg, 0);
                boolean isSplit = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                String name = outName(pm, ai, pi, isSplit);
                String mime = isSplit ? "application/octet-stream" : "application/vnd.android.package-archive";
                String shown;
                OutputStream os;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContext().getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) { call.reject("Не удалось создать файл в Загрузках"); return; }
                    os = getContext().getContentResolver().openOutputStream(uri);
                    shown = "Download/" + name;
                } else {
                    File d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    d.mkdirs();
                    File out = new File(d, name);
                    os = new FileOutputStream(out);
                    shown = out.getAbsolutePath();
                }
                writePackage(ai, isSplit, os);
                os.close();
                JSObject ret = new JSObject();
                ret.put("name", name);
                ret.put("path", shown);
                call.resolve(ret);
            } catch (Exception e) { call.reject(e.getMessage() == null ? "Ошибка извлечения" : e.getMessage()); }
        }).start();
    }

    /* ===== Поделиться APK (сборка во внутренний кэш → системный chooser) ===== */
    @PluginMethod
    public void shareApk(PluginCall call) {
        String pkg = call.getString("pkg");
        if (pkg == null) { call.reject("no pkg"); return; }
        new Thread(() -> {
            try {
                PackageManager pm = getContext().getPackageManager();
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                PackageInfo pi = pm.getPackageInfo(pkg, 0);
                boolean isSplit = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                String name = outName(pm, ai, pi, isSplit);
                String mime = isSplit ? "application/octet-stream" : "application/vnd.android.package-archive";
                File dir = new File(getContext().getCacheDir(), "share");
                dir.mkdirs();
                for (File old : dir.listFiles() == null ? new File[0] : dir.listFiles()) { try { old.delete(); } catch (Exception ignored) {} }
                File out = new File(dir, name);
                OutputStream os = new FileOutputStream(out);
                writePackage(ai, isSplit, os);
                os.close();
                try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, contentUriFor(out));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(i, "Поделиться");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(ch);
                call.resolve();
            } catch (Exception e) { call.reject(e.getMessage() == null ? "Ошибка" : e.getMessage()); }
        }).start();
    }

    /* ===== Поделиться несколькими APK разом ===== */
    @PluginMethod
    public void shareApks(PluginCall call) {
        JSArray pkgs = call.getArray("pkgs");
        if (pkgs == null || pkgs.length() == 0) { call.reject("no pkgs"); return; }
        new Thread(() -> {
            try {
                PackageManager pm = getContext().getPackageManager();
                File dir = new File(getContext().getCacheDir(), "share");
                dir.mkdirs();
                for (File old : dir.listFiles() == null ? new File[0] : dir.listFiles()) { try { old.delete(); } catch (Exception ignored) {} }
                ArrayList<Uri> uris = new ArrayList<>();
                boolean allApk = true;
                for (int i = 0; i < pkgs.length(); i++) {
                    String pkg = pkgs.getString(i);
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    PackageInfo pi = pm.getPackageInfo(pkg, 0);
                    boolean isSplit = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                    if (isSplit) allApk = false;
                    File out = new File(dir, outName(pm, ai, pi, isSplit));
                    OutputStream os = new FileOutputStream(out);
                    writePackage(ai, isSplit, os);
                    os.close();
                    uris.add(contentUriFor(out));
                }
                try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
                Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                i.setType(allApk ? "application/vnd.android.package-archive" : "application/octet-stream");
                i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(i, "Поделиться");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(ch);
                call.resolve();
            } catch (Exception e) { call.reject(e.getMessage() == null ? "Ошибка" : e.getMessage()); }
        }).start();
    }

    /* ===== Удаление приложения (системный диалог) ===== */
    @PluginMethod
    public void uninstall(PluginCall call) {
        String pkg = call.getString("pkg");
        if (pkg == null) { call.reject("no pkg"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /* ===== Открыть приложение ===== */
    @PluginMethod
    public void openApp(PluginCall call) {
        String pkg = call.getString("pkg");
        if (pkg == null) { call.reject("no pkg"); return; }
        try {
            Intent i = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { call.reject("Нет активности запуска"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Пакеты, где оболочки держат экраны настроек/разрешений
    private java.util.List<String> settingsPackages() {
        java.util.ArrayList<String> out = new java.util.ArrayList<>();
        out.add("com.android.settings");
        try {
            for (PackageInfo p : getContext().getPackageManager().getInstalledPackages(0)) {
                String n = p.packageName.toLowerCase();
                if (n.equals("com.android.settings")) continue;
                if (n.contains("settings") || n.contains("permission") || n.contains("securitypermission") || n.contains("appmanager"))
                    out.add(p.packageName);
            }
        } catch (Exception ignored) {}
        return out;
    }

    // Поиск экспортированных activity в пакете Настроек по подстрокам имени (группы в порядке приоритета).
    // excl — подстроки-исключения: отсекают экраны конкретных разрешений, когда нужен общий список.
    private void addSettingsMatches(java.util.ArrayList<Intent> cands, String[][] groups, String[] excl) {
        try {
            java.util.ArrayList<android.content.pm.ActivityInfo> acts = new java.util.ArrayList<>();
            for (String pkgName : settingsPackages()) {
                try {
                    android.content.pm.PackageInfo pi = getContext().getPackageManager().getPackageInfo(pkgName, PackageManager.GET_ACTIVITIES);
                    if (pi.activities != null) java.util.Collections.addAll(acts, pi.activities);
                } catch (Exception ignored) {}
            }
            for (String[] g : groups) {
                int added = 0;
                for (android.content.pm.ActivityInfo a : acts) {
                    if (!a.exported || added >= 5) continue;
                    String n = a.name.toLowerCase();
                    boolean all = true;
                    for (String sub : g) if (!n.contains(sub)) { all = false; break; }
                    if (!all) continue;
                    boolean bad = false;
                    if (excl != null) for (String ex : excl) if (n.contains(ex)) { bad = true; break; }
                    if (bad) continue;
                    cands.add(new Intent().setClassName(a.packageName, a.name));
                    added++;
                }
            }
        } catch (Exception ignored) {}
    }

    // SPA-роутер настроек (Android 14+): экраны по имени destination
    private Intent spaIntent(String cls, String dest) {
        Intent i = new Intent().setClassName("com.android.settings", cls);
        i.putExtra("spaActivityDestination", dest);
        return i;
    }

    /* ===== Открытие системных экранов (с фолбэками под разные оболочки) ===== */
    @PluginMethod
    public void openScreen(PluginCall call) {
        String screen = call.getString("screen", "");
        java.util.ArrayList<Intent> cands = new java.util.ArrayList<>();
        if ("special_access".equals(screen)) {
            // те же oplus-алиасы, что и у спец. возможностей (по образцу имени с прошивки юзера)
            cands.add(new Intent().setClassName("com.oplus.settings", "com.oplus.settings.OplusSettingsActivity$OplusSpecialAccessSettingsActivity"));
            cands.add(new Intent().setClassName("com.oplus.settings", "com.oplus.settings.OplusSettingsActivity$SpecialAccessSettingsActivity"));
            cands.add(new Intent().setClassName("com.oplus.settings", "com.oplus.settings.OplusSettingsActivity$OplusSpecialAppAccessSettingsActivity"));
            cands.add(new Intent().setClassName("com.android.settings", "com.android.settings.Settings$SpecialAccessSettingsActivity"));
            cands.add(spaIntent("com.android.settings.spa.SpaBridgeActivity", "SpecialAppAccessList"));
            cands.add(spaIntent("com.android.settings.spa.SpaBridgeActivity", "SpecialAppAccess"));
            cands.add(spaIntent("com.android.settings.spa.SpaActivity", "SpecialAppAccessList"));
            String[] exclPerm = { "deviceadmin", "premiumsms", "notificationaccess", "notificationlistener", "usageaccess", "overlay", "drawoverlay", "writesettings", "zenaccess", "dnd", "pictureinpicture", "managemedia", "mediamanage", "wificontrol", "changewifistate", "nfctag", "turnscreen", "alarmsandreminder", "fullscreenintent", "installunknown", "manageexternalstorage", "allfilesaccess", "vrlistener", "batteryoptim", "ignorebattery" };
            addSettingsMatches(cands, new String[][] {
                { "specialaccess", "dashboard" }, { "specialaccess", "settingsactivity" }, { "specialappaccess", "list" },
                { "specialaccess", "main" }, { "specialaccess" }, { "specialappaccess" }, { "special_access" } }, exclPerm);
            cands.add(new Intent("android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS"));
            cands.add(new Intent(Settings.ACTION_SETTINGS));
        } else if ("default_apps".equals(screen)) {
            if (Build.VERSION.SDK_INT >= 24) cands.add(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
            cands.add(new Intent().setClassName("com.android.settings", "com.android.settings.Settings$ManageDefaultAppsActivity"));
            cands.add(new Intent(Settings.ACTION_HOME_SETTINGS));
            cands.add(new Intent(Settings.ACTION_SETTINGS));
        } else if ("accessibility".equals(screen)) {
            // цель — экран «Скачанные приложения» внутри спец. возможностей
            // точное имя с прошивки юзера (ColorOS/OxygenOS):
            cands.add(new Intent().setClassName("com.oplus.settings", "com.oplus.settings.OplusSettingsActivity$OplusAccessibilityDownloadedSettingsActivity"));
            cands.add(new Intent().setClassName("com.android.settings", "com.oplus.settings.OplusSettingsActivity$OplusAccessibilityDownloadedSettingsActivity"));
            addSettingsMatches(cands, new String[][] {
                { "accessib", "install" }, { "accessib", "download" }, { "a11y", "install" }, { "a11y", "download" },
                { "accessib", "downloaded" } }, null);
            cands.add(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            cands.add(new Intent(Settings.ACTION_SETTINGS));
        } else if ("disabled_apps".equals(screen)) {
            cands.add(new Intent("android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS"));
            cands.add(new Intent(Settings.ACTION_APPLICATION_SETTINGS));
            cands.add(new Intent(Settings.ACTION_SETTINGS));
        } else { call.reject("unknown screen"); return; }

        PackageManager pm = getContext().getPackageManager();
        StringBuilder tried = new StringBuilder();
        for (Intent i : cands) {
            try {
                // явные компоненты: проверяем, что activity существует и экспортирована — иначе пропускаем без попытки
                if (i.getComponent() != null) {
                    android.content.pm.ResolveInfo ri = pm.resolveActivity(i, 0);
                    if (ri == null || ri.activityInfo == null) { tried.append(short_(i)).append(": нет; "); continue; }
                    if (!ri.activityInfo.exported) { tried.append(short_(i)).append(": закрыта; "); continue; }
                }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                JSObject ret = new JSObject();
                ret.put("opened", short_(i));
                call.resolve(ret);
                return;
            } catch (Exception e) { tried.append(short_(i)).append(": ").append(e.getClass().getSimpleName()).append("; "); }
        }
        call.reject("Не открылось. Пробовал: " + tried);
    }

    private String short_(Intent i) {
        if (i.getComponent() != null) {
            String c = i.getComponent().getClassName();
            String dest = i.getStringExtra("spaActivityDestination");
            return c.substring(c.lastIndexOf('.') + 1) + (dest != null ? "→" + dest : "");
        }
        String a = i.getAction() == null ? "?" : i.getAction();
        return a.substring(a.lastIndexOf('.') + 1);
    }

    /* ===== Пункты «Специального доступа», реально доступные на текущей прошивке =====
       Каталог — суперсет по всем прошивкам; каждый пункт проверяется resolveActivity,
       поэтому список сам сужается/расширяется под конкретную оболочку. */
    @PluginMethod
    public void saItems(PluginCall call) {
        PackageManager pm = getContext().getPackageManager();
        JSArray arr = new JSArray();
        Object[][] cat = {
            { "Доступ ко всем файлам", "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION", 30 },
            { "Поверх других приложений", "android.settings.action.MANAGE_OVERLAY_PERMISSION", 23 },
            { "Изменить системные настройки", "android.settings.action.MANAGE_WRITE_SETTINGS", 23 },
            { "Уведомления устройства и приложений", "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS", 22 },
            { "Данные об использовании", "android.settings.USAGE_ACCESS_SETTINGS", 21 },
            { "Доступ к режиму «Не беспокоить»", "android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS", 23 },
            { "Установка неизвестных приложений", "android.settings.MANAGE_UNKNOWN_APP_SOURCES", 26 },
            { "Будильники и напоминания", "android.settings.REQUEST_SCHEDULE_EXACT_ALARM", 31 },
            { "Управление приложениями мультимедиа", "android.settings.REQUEST_MANAGE_MEDIA", 31 },
            { "«Картинка в картинке» (PIP)", "android.settings.PICTURE_IN_PICTURE_SETTINGS", 26 },
            { "VR-помощники", "android.settings.VR_LISTENER_SETTINGS", 24 },
        };
        for (Object[] row : cat) {
            String label = (String) row[0], action = (String) row[1];
            int min = (Integer) row[2];
            if (Build.VERSION.SDK_INT < min) continue;
            try {
                if (pm.resolveActivity(new Intent(action), 0) == null) continue;
                JSObject o = new JSObject();
                o.put("label", label);
                o.put("action", action);
                arr.put(o);
            } catch (Exception ignored) {}
        }
        // Премиум-SMS: публичного action нет — компонент/поиск по оболочке
        try {
            java.util.ArrayList<Intent> ps = new java.util.ArrayList<>();
            ps.add(new Intent().setClassName("com.android.settings", "com.android.settings.Settings$PremiumSmsAccessActivity"));
            addSettingsMatches(ps, new String[][] { { "premiumsms" }, { "premium_sms" } }, null);
            for (Intent i : ps) {
                android.content.pm.ResolveInfo ri = pm.resolveActivity(i, 0);
                if (ri == null || ri.activityInfo == null || !ri.activityInfo.exported) continue;
                JSObject o = new JSObject();
                o.put("label", "Доступ к премиум-SMS");
                o.put("cls", i.getComponent().getPackageName() + "|" + i.getComponent().getClassName());
                arr.put(o);
                break;
            }
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("items", arr);
        call.resolve(ret);
    }

    /* ===== Открыть экран по action ===== */
    @PluginMethod
    public void openAction(PluginCall call) {
        String action = call.getString("action");
        if (action == null) { call.reject("no action"); return; }
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("Экран недоступен на этой прошивке"); }
    }

    /* ===== Скачанные (несистемные) службы спец. возможностей ===== */
    @PluginMethod
    public void a11yServices(PluginCall call) {
        try {
            PackageManager pm = getContext().getPackageManager();
            android.view.accessibility.AccessibilityManager am =
                (android.view.accessibility.AccessibilityManager) getContext().getSystemService(android.content.Context.ACCESSIBILITY_SERVICE);
            java.util.List<android.accessibilityservice.AccessibilityServiceInfo> installed = am.getInstalledAccessibilityServiceList();
            String enabled = Settings.Secure.getString(getContext().getContentResolver(), "enabled_accessibility_services");
            if (enabled == null) enabled = "";
            JSArray arr = new JSArray();
            for (android.accessibilityservice.AccessibilityServiceInfo info : installed) {
                android.content.pm.ResolveInfo ri = info.getResolveInfo();
                if (ri == null || ri.serviceInfo == null || ri.serviceInfo.applicationInfo == null) continue;
                android.content.pm.ServiceInfo si = ri.serviceInfo;
                boolean sys = (si.applicationInfo.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                if (sys) continue; // «для пользовательских приложений»
                JSObject o = new JSObject();
                String label;
                try { label = String.valueOf(ri.loadLabel(pm)); } catch (Exception e) { label = si.packageName; }
                o.put("label", label);
                o.put("pkg", si.packageName);
                o.put("cls", si.name);
                o.put("set", info.getSettingsActivityName() == null ? "" : info.getSettingsActivityName()); // собственный экран настроек службы
                o.put("on", enabled.contains(si.packageName + "/"));
                arr.put(o);
            }
            JSObject ret = new JSObject();
            ret.put("services", arr);
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /* ===== Страница конкретной службы спец. возможностей: детали → свои настройки службы → о приложении ===== */
    @PluginMethod
    public void openA11yService(PluginCall call) {
        String pkg = call.getString("pkg");
        String cls = call.getString("cls");
        String set = call.getString("set", "");
        if (pkg == null || cls == null) { call.reject("no component"); return; }
        PackageManager pm = getContext().getPackageManager();
        // 1) системная страница переключателя службы (AOSP/OneUI, API 30+)
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS");
                i.putExtra(Intent.EXTRA_COMPONENT_NAME, new android.content.ComponentName(pkg, cls).flattenToString());
                if (pm.resolveActivity(i, 0) != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                    call.resolve();
                    return;
                }
            } catch (Exception ignored) {}
        }
        // 2) экран настроек, который объявила сама служба
        if (set != null && !set.isEmpty()) {
            try {
                Intent i = new Intent().setClassName(pkg, set);
                android.content.pm.ResolveInfo ri = pm.resolveActivity(i, 0);
                if (ri != null && ri.activityInfo != null && ri.activityInfo.exported) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                    call.resolve();
                    return;
                }
            } catch (Exception ignored) {}
        }
        // 3) системная карточка «О приложении»
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /* ===== Диагностика: перечень экспортированных activity Настроек и запуск любой из них ===== */
    @PluginMethod
    public void settingsActivities(PluginCall call) {
        String q = call.getString("q", "");
        final String ql = q == null ? "" : q.toLowerCase();
        try {
            JSArray arr = new JSArray();
            int n = 0;
            for (String pkgName : settingsPackages()) {
                if (n >= 500) break;
                try {
                    android.content.pm.PackageInfo pi = getContext().getPackageManager().getPackageInfo(pkgName, PackageManager.GET_ACTIVITIES);
                    if (pi.activities == null) continue;
                    for (android.content.pm.ActivityInfo a : pi.activities) {
                        if (!a.exported) continue;
                        String full = pkgName + "|" + a.name;
                        if (!ql.isEmpty() && !full.toLowerCase().contains(ql)) continue;
                        arr.put(full);
                        if (++n >= 500) break;
                    }
                } catch (Exception ignored) {}
            }
            JSObject ret = new JSObject();
            ret.put("list", arr);
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void launchSettingsActivity(PluginCall call) {
        String cls = call.getString("cls");
        if (cls == null) { call.reject("no cls"); return; }
        try {
            String pkg = "com.android.settings";
            int sep = cls.indexOf('|');
            if (sep > 0) { pkg = cls.substring(0, sep); cls = cls.substring(sep + 1); }
            Intent i = new Intent().setClassName(pkg, cls);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getClass().getSimpleName() + ": " + e.getMessage()); }
    }

    /* ===== Системные настройки приложения ===== */
    @PluginMethod
    public void appSettings(PluginCall call) {
        String pkg = call.getString("pkg");
        if (pkg == null) { call.reject("no pkg"); return; }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /* ===== Цвет системных панелей ===== */
    @PluginMethod
    public void setBars(PluginCall call) {
        final String color = call.getString("color", "#000000");
        final boolean light = call.getBoolean("light", false);
        try {
            getActivity().runOnUiThread(() -> {
                try {
                    Window w = getActivity().getWindow();
                    int c = Color.parseColor(color);
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
        call.resolve();
    }

    /* ===== Хелперы ===== */

    // Имя выходного файла: Метка_версия.apk / .apks
    private String outName(PackageManager pm, ApplicationInfo ai, PackageInfo pi, boolean isSplit) {
        String label;
        try { label = pm.getApplicationLabel(ai).toString(); } catch (Exception e) { label = ai.packageName; }
        String ver = pi.versionName != null && !pi.versionName.isEmpty() ? pi.versionName
                : String.valueOf(Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
        return sanitize(label) + "_" + sanitize(ver) + (isSplit ? ".apks" : ".apk");
    }

    // base.apk напрямую, либо zip из base + всех split-ов
    private void writePackage(ApplicationInfo ai, boolean isSplit, OutputStream os) throws Exception {
        if (!isSplit) {
            copyStream(new FileInputStream(ai.sourceDir), os);
            return;
        }
        ZipOutputStream zos = new ZipOutputStream(os);
        zos.setLevel(0); // APK уже сжаты — быстрее без пересжатия
        putZip(zos, new File(ai.sourceDir), "base.apk");
        for (String s : ai.splitSourceDirs) {
            File f = new File(s);
            putZip(zos, f, f.getName());
        }
        zos.finish();
    }

    private void putZip(ZipOutputStream zos, File f, String name) throws Exception {
        zos.putNextEntry(new ZipEntry(name));
        copyStream(new FileInputStream(f), zos);
        zos.closeEntry();
    }

    private void copyStream(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[262144];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
    }

    private String sanitize(String s) {
        return s.replaceAll("[\\\\/:*?\"<>|\\s]+", "_").replaceAll("_+", "_");
    }

    private Uri contentUriFor(File f) {
        String pkg = getContext().getPackageName();
        try { return FileProvider.getUriForFile(getContext(), pkg + ".fileprovider", f); } catch (Exception ignored) {}
        try { return FileProvider.getUriForFile(getContext(), pkg + ".appsfp", f); } catch (Exception ignored) {}
        try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
        return Uri.fromFile(f);
    }

    private Bitmap drawableToBitmap(Drawable d) {
        try {
            if (d instanceof BitmapDrawable) {
                Bitmap b = ((BitmapDrawable) d).getBitmap();
                if (b != null) return b;
            }
            int w = Math.max(1, d.getIntrinsicWidth());
            int h = Math.max(1, d.getIntrinsicHeight());
            if (w > 512) w = 512;
            if (h > 512) h = 512;
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, c.getWidth(), c.getHeight());
            d.draw(c);
            return b;
        } catch (Exception e) { return null; }
    }
}
