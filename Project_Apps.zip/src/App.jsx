import React, { useState, useEffect, useRef, useMemo } from "react";
import { App as CapApp } from "@capacitor/app";
import { registerPlugin, Capacitor } from "@capacitor/core";
import VER from "../version.json";
const Apps = registerPlugin("Apps");

/* ===== Apps — leshugan.ma ===== */

const APP_VERSION = VER.version;
const LKEY = "ma_apps_v1", IKEY = "ma_icons_v1", HKEY = "ma_hidden_v1", TKEY = "ma_theme_v1", SKEY = "ma_sort_v1";

const ls = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
};

/* ===== Темы (палитры как у ProPDA, перенос из 4PDApps и адаптация под Apps) ===== */
const THEMES = [
  { id: "dark",      name: "Тёмная",     bg: "#1B130B", bar: "#2C2219", card: "#332619", border: "#4A3A2A", text: "#F2EAE0", sub: "#B0A498", nav: "#E0D5C8", acc: "#EF6C00", light: false },
  { id: "amoled",    name: "AMOLED",     bg: "#000000", bar: "#0C0C0C", card: "#141414", border: "#242424", text: "#D8D4CE", sub: "#8A8178", nav: "#B4ACA3", acc: "#EF6C00", light: false },
  { id: "light",     name: "Светлая",    bg: "#EEF1F4", bar: "#FFFFFF", card: "#E4E8EC", border: "#D3D8DE", text: "#1E2329", sub: "#6B7280", nav: "#3D4754", acc: "#2F80ED", light: true }, // бело-голубая, как в YevGallery
  { id: "gruvbox",   name: "Gruvbox",    bg: "#282828", bar: "#32302F", card: "#3C3836", border: "#504945", text: "#EBDBB2", sub: "#A89984", nav: "#D5C4A1", acc: "#FE8019", light: false },
  { id: "dracula",   name: "Dracula",    bg: "#282A36", bar: "#343746", card: "#44475A", border: "#4D5066", text: "#F8F8F2", sub: "#A9ADC4", nav: "#D0D2E0", acc: "#BD93F9", light: false },
  { id: "nord",      name: "Nord",       bg: "#2E3440", bar: "#3B4252", card: "#434C5E", border: "#4C566A", text: "#ECEFF4", sub: "#A9B1C2", nav: "#D8DEE9", acc: "#88C0D0", light: false },
  { id: "rosepine",  name: "Rosé Pine",  bg: "#191724", bar: "#1F1D2E", card: "#26233A", border: "#302D44", text: "#E0DEF4", sub: "#A29FC0", nav: "#D5D3EA", acc: "#C4A7E7", light: false },
  { id: "solarized", name: "Solarized",  bg: "#002B36", bar: "#073642", card: "#0E4B5A", border: "#14606F", text: "#93A1A1", sub: "#6A8286", nav: "#EEE8D5", acc: "#268BD2", light: false },
  { id: "sepia",     name: "Sepia",      bg: "#F4ECD8", bar: "#FFF9EE", card: "#F0E4CC", border: "#D6C5AE", text: "#5B4636", sub: "#8A7359", nav: "#6B5842", acc: "#8A5A2B", light: true },
  { id: "greencare", name: "Green Care", bg: "#C8E6C9", bar: "#DFF0E1", card: "#D2E8D4", border: "#AACDAD", text: "#1B3A2B", sub: "#4A6B52", nav: "#3A5A44", acc: "#2E7D4F", light: true },
];
const THEME_BY = {}; THEMES.forEach((t) => { THEME_BY[t.id] = t; });
const rgbOf = (h) => { const x = h.replace("#", ""); return [parseInt(x.slice(0, 2), 16), parseInt(x.slice(2, 4), 16), parseInt(x.slice(4, 6), 16)]; };
const darken = (h, k) => { const [r, g, b] = rgbOf(h); const f = (v) => Math.max(0, Math.round(v * (1 - k))).toString(16).padStart(2, "0"); return "#" + f(r) + f(g) + f(b); };
const onColor = (h) => { const [r, g, b] = rgbOf(h); return (0.299 * r + 0.587 * g + 0.114 * b) > 160 ? "#10100E" : "#FFFFFF"; };

const C = {};
const resolveThemeId = (id) => {
  if (id === "system") { try { return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark"; } catch { return "dark"; } }
  return THEME_BY[id] ? id : "dark";
};
function applyTheme(id) {
  const saved = id || ls.get(TKEY) || "dark";
  const t = THEME_BY[resolveThemeId(saved)];
  const [r, g, b] = rgbOf(t.acc);
  Object.assign(C, {
    bg: t.bg, bar: t.bar, row2: t.card, line: t.border,
    txt: t.text, ink: t.nav, sub: t.sub,
    acc: t.acc, onAcc: onColor(t.acc),
    accbg: `rgba(${r},${g},${b},${t.light ? 0.16 : 0.2})`,
    fab: darken(t.acc, t.light ? 0.18 : 0.38), // лупа: менее яркая, более глубокая
    red: t.light ? "#D14343" : "#E05252",
    chip: t.light ? "rgba(0,0,0,.06)" : "rgba(255,255,255,.06)",
    barsh: t.light ? "0 4px 14px rgba(0,0,0,.14), 0 1px 3px rgba(0,0,0,.10)" : "0 6px 18px rgba(0,0,0,.34), 0 1px 4px rgba(0,0,0,.26)",
    light: !!t.light,
  });
  C.onFab = onColor(C.fab);
  try { document.documentElement.style.background = C.bg; document.body.style.background = C.bg; } catch {}
  try { Apps.setBars({ color: C.bg, light: !!t.light }); } catch {}
}
applyTheme();
const buzz = (ms) => { try { navigator.vibrate && navigator.vibrate(ms); } catch {} };
const fmtSize = (b) => { if (!b) return ""; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i]; };

const I = {
  dl: <><path d="M12 3v12" /><path d="M7 11l5 5 5-5" /><path d="M5 21h14" /></>,
  share: <><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4" /></>,
  trash: <><path d="M3 6h18" /><path d="M8 6V4h8v2" /><path d="M6 6l1 14h10l1-14" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></>,
  x: <><path d="M18 6L6 18" /><path d="M6 6l12 12" /></>,
  check: <path d="M20 6L9 17l-5-5" />,
  eye: <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></>,
  hide: <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" /><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" /><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24" /><path d="M1 1l22 22" /></>,
  back: <><path d="M19 12H5" /><path d="M12 19l-7-7 7-7" /></>,
  dots: <g fill="currentColor" stroke="none"><circle cx="12" cy="5" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="12" cy="19" r="2" /></g>,
  android: <g stroke="none"><path d="M7 6 L5.6 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M17 6 L18.4 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill="currentColor" /><rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill="currentColor" /><rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><circle cx="9.6" cy="8.8" r=".85" fill="#0d0d0d" /><circle cx="14.4" cy="8.8" r=".85" fill="#0d0d0d" /></g>,
};
const Svg = ({ d, size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);

/* ===== Лента панелей (упрощённая v14 из 4PDApps): палец ведёт transform, снап, обе панели всегда смонтированы ===== */
const Pager = ({ ctlRef, onFrac, onActive, children }) => {
  const wrapRef = useRef(null);
  const stripRef = useRef(null);
  const fracRef = useRef(0);
  const snapRef = useRef(null);
  const onFracRef = useRef(onFrac); onFracRef.current = onFrac;
  const onActiveRef = useRef(onActive); onActiveRef.current = onActive;

  const applyFrac = (f) => {
    fracRef.current = f;
    const s = stripRef.current;
    if (s) s.style.transform = "translate3d(" + (-f * 50) + "%,0,0)";
    if (onFracRef.current) onFracRef.current(f); // подсветка вкладок ведётся тем же кадром — поспевает за анимацией
  };
  useEffect(() => { applyFrac(fracRef.current); }); // защита: каждый рендер переприменяет transform

  const snapTo = (idx) => {
    if (snapRef.current) cancelAnimationFrame(snapRef.current);
    const from = fracRef.current, to = idx, t0 = performance.now(), dur = 170;
    const step = (t) => {
      let p = Math.min(1, (t - t0) / dur);
      p = 1 - (1 - p) * (1 - p);
      applyFrac(from + (to - from) * p);
      if (p < 1) snapRef.current = requestAnimationFrame(step);
      else { snapRef.current = null; if (onActiveRef.current) onActiveRef.current(idx); }
    };
    snapRef.current = requestAnimationFrame(step);
  };
  if (ctlRef) ctlRef.current = { snapTo };

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    let g = null;
    const ts = (e) => {
      if (e.touches.length !== 1) { g = null; return; }
      g = { x0: e.touches[0].clientX, y0: e.touches[0].clientY, lock: 0, f0: fracRef.current, lx: e.touches[0].clientX, lt: performance.now(), vx: 0 };
    };
    const tm = (e) => {
      if (!g) return;
      const x = e.touches[0].clientX, y = e.touches[0].clientY;
      const dx = x - g.x0, dy = y - g.y0;
      if (g.lock === 0) {
        if (Math.abs(dx) > 8 && Math.abs(dx) > 1.15 * Math.abs(dy)) g.lock = 1;
        else if (Math.abs(dy) > 8 && Math.abs(dy) > 1.15 * Math.abs(dx)) g.lock = -1;
      }
      if (g.lock === 1) {
        e.preventDefault();
        const w = el.clientWidth || 1;
        const now = performance.now();
        if (now > g.lt) g.vx = (x - g.lx) / (now - g.lt);
        g.lx = x; g.lt = now;
        applyFrac(Math.max(0, Math.min(1, g.f0 - dx / w)));
      }
    };
    const te = () => {
      if (!g) return;
      if (g.lock === 1) {
        const f = fracRef.current, base = Math.round(g.f0);
        const dev = f - g.f0;
        let t = base;
        if (g.vx < -0.45 || dev > 0.02) t = base + 1;
        else if (g.vx > 0.45 || dev < -0.02) t = base - 1;
        t = Math.max(0, Math.min(1, t));
        snapTo(t);
      }
      g = null;
    };
    el.addEventListener("touchstart", ts, { passive: true });
    el.addEventListener("touchmove", tm, { passive: false });
    el.addEventListener("touchend", te, { passive: true });
    el.addEventListener("touchcancel", te, { passive: true });
    return () => { el.removeEventListener("touchstart", ts); el.removeEventListener("touchmove", tm); el.removeEventListener("touchend", te); el.removeEventListener("touchcancel", te); };
  }, []);

  return (
    <div ref={wrapRef} style={{ position: "absolute", inset: 0, overflow: "hidden" }}>
      <div ref={stripRef} style={{ width: "200%", height: "100%", display: "flex", willChange: "transform" }}>
        {children}
      </div>
    </div>
  );
};

/* ===== Вкладки со скользящей подсветкой (движется тем же кадром, что и лента) ===== */
const TabBar = ({ ctlRef, labels, counts, onTap, onHold }) => {
  const holdT = useRef(null);
  const held = useRef(false);
  const pillRef = useRef(null);
  const txtRefs = useRef([]);
  const badgeRefs = useRef([]);
  const lastF = useRef(0);
  const paint = (f) => {
    lastF.current = f;
    const p = pillRef.current;
    if (p) p.style.transform = "translateX(" + f * 100 + "%)";
    const on = Math.round(f);
    for (let i = 0; i < labels.length; i++) {
      const t = txtRefs.current[i];
      if (t) t.style.color = i === on ? C.onAcc : C.sub;
      const b = badgeRefs.current[i];
      if (b) { b.style.background = i === on ? (C.light ? "rgba(255,255,255,.30)" : "rgba(0,0,0,.22)") : C.chip; b.style.color = i === on ? C.onAcc : C.sub; }
    }
  };
  if (ctlRef) ctlRef.current = { paint };
  useEffect(() => { paint(lastF.current); }); // рендер перезаписывает inline-стили — восстанавливаем

  return (
    <div style={{ position: "relative", display: "flex", background: C.chip, borderRadius: 14, padding: 3 }}>
      <div ref={pillRef} style={{ position: "absolute", top: 3, bottom: 3, left: 3, width: "calc(50% - 3px)", borderRadius: 11, background: C.acc, willChange: "transform" }} />
      {labels.map((t, i) => (
        <button key={i}
          onClick={() => { if (held.current) { held.current = false; return; } onTap(i); }}
          onTouchStart={() => { held.current = false; clearTimeout(holdT.current); if (onHold) holdT.current = setTimeout(() => { held.current = true; onHold(); }, 450); }}
          onTouchMove={() => clearTimeout(holdT.current)}
          onTouchEnd={() => clearTimeout(holdT.current)}
          onContextMenu={(e) => e.preventDefault()}
          style={{ flex: "1 1 0", minWidth: 0, zIndex: 1, border: "none", borderRadius: 11, padding: "8px 6px", fontSize: 14, fontWeight: 600, background: "transparent", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, overflow: "hidden", WebkitUserSelect: "none", userSelect: "none", WebkitTouchCallout: "none" }}>
          <span ref={(el) => (txtRefs.current[i] = el)} style={{ color: C.sub, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t}</span>
          {counts && counts[i] != null && (
            <span ref={(el) => (badgeRefs.current[i] = el)} style={{ flex: "0 0 auto", fontSize: 11, fontWeight: 700, background: C.chip, color: C.sub, borderRadius: 9, padding: "1px 7px", minWidth: 14, textAlign: "center" }}>{counts[i]}</span>
          )}
        </button>
      ))}
    </div>
  );
};

const RowBtn = ({ icon, color, onClick }) => (
  <button
    onClick={(e) => { e.stopPropagation(); onClick(); }}
    style={{ width: 36, height: 36, borderRadius: 18, border: "none", background: C.chip, color: color || C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0, flex: "0 0 auto" }}
  >
    <Svg d={icon} size={18} />
  </button>
);

const Row = React.memo(function Row({ a, icSrc, inSel, checked, onToggle, onStartSel, selRef, onExtract, onShare, onUninstall, onIconClick, theme }) {
  const lp = useRef(null);
  const moved = useRef(false);
  const p0 = useRef(null);
  return (
    <div
      onTouchStart={(e) => {
        moved.current = false;
        p0.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        clearTimeout(lp.current);
        lp.current = setTimeout(() => { if (!moved.current && !selRef.current) onStartSel(a.pkg); }, 450);
      }}
      onTouchMove={(e) => {
        if (!p0.current) return;
        if (Math.abs(e.touches[0].clientX - p0.current.x) > 10 || Math.abs(e.touches[0].clientY - p0.current.y) > 10) { moved.current = true; clearTimeout(lp.current); }
      }}
      onTouchEnd={() => clearTimeout(lp.current)}
      onContextMenu={(e) => e.preventDefault()}
      onClick={() => { if (inSel) onToggle(a.pkg); }}
      style={{ display: "flex", alignItems: "center", gap: 10, background: checked ? C.accbg : C.bar, borderRadius: 16, padding: "9px 10px", marginBottom: 6, WebkitUserSelect: "none", userSelect: "none", minWidth: 0 }}
    >
      <span onClick={(e) => { if (!inSel) { e.stopPropagation(); onIconClick(a); } }} style={{ flex: "0 0 auto", display: "flex" }}>
        {icSrc ? (
          <img src={icSrc} alt="" width={42} height={42} style={{ borderRadius: 10 }} />
        ) : (
          <span style={{ width: 42, height: 42, borderRadius: 10, background: C.chip, color: C.sub, display: "flex", alignItems: "center", justifyContent: "center" }}><Svg d={I.android} size={24} /></span>
        )}
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.label}</div>
        <div style={{ fontSize: 12, color: C.sub, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {a.ver || "—"}{a.size ? " · " + fmtSize(a.size) : ""}{a.split ? " · split" : ""}
        </div>
      </div>
      {inSel ? (
        <span style={{ width: 26, height: 26, borderRadius: 13, flex: "0 0 auto", display: "flex", alignItems: "center", justifyContent: "center", background: checked ? C.acc : "transparent", border: checked ? "none" : "2px solid " + C.line, color: C.onAcc }}>
          {checked && <Svg d={I.check} size={16} />}
        </span>
      ) : (
        <>
          <RowBtn icon={I.dl} color={C.acc} onClick={() => onExtract(a)} />
          <RowBtn icon={I.share} onClick={() => onShare(a)} />
          <RowBtn icon={I.trash} color={C.red} onClick={() => onUninstall(a)} />
        </>
      )}
    </div>
  );
});

const MenuBtn = ({ label, onClick }) => (
  <button onClick={onClick}
    style={{ display: "block", width: "100%", textAlign: "left", border: "none", background: "transparent", color: C.txt, fontSize: 14.5, padding: "12px 14px", borderRadius: 11 }}>
    {label}
  </button>
);

const SelBtn = ({ icon, color, onClick }) => (
  <button onClick={onClick}
    style={{ width: 44, height: 44, borderRadius: 22, border: "none", background: C.chip, color: color || C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0, flex: "0 0 auto" }}>
    <Svg d={icon} size={20} />
  </button>
);

export default function App() {
  const [apps, setApps] = useState(() => { try { return JSON.parse(ls.get(LKEY)); } catch { return null; } });
  const [icons, setIcons] = useState(() => { try { return JSON.parse(ls.get(IKEY)) || {}; } catch { return {}; } });
  const [hidden, setHidden] = useState(() => { try { return JSON.parse(ls.get(HKEY)) || []; } catch { return []; } });
  const [sel, setSel] = useState(null);         // выделение на главном экране
  const [hSel, setHSel] = useState(null);       // выделение на экране скрытых
  const [overlay, setOverlay] = useState(null); // null | 'hidden' | 'disabled'
  const [menuOpen, setMenuOpen] = useState(false);
  const [diag, setDiag] = useState(null); // {q, list} — диагностика экранов настроек
  const [menuView, setMenuView] = useState("root"); // root | sa | a11y
  const [a11y, setA11y] = useState([]);
  const [saList, setSaList] = useState([]);
  const [saOpen, setSaOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(null);
  const [toast, setToast] = useState(null);
  const [theme, setTheme] = useState(() => ls.get(TKEY) || "dark");
  const [sortBy, setSortBy] = useState(() => ls.get(SKEY) || "name");
  const [sortOpen, setSortOpen] = useState(false);
  const [settings, setSettings] = useState(null); // null | 'root' | 'theme'

  /* ---- refs (все объявления выше первого использования — урок TDZ) ---- */
  const toastT = useRef(null);
  const iconsRef = useRef(icons); iconsRef.current = icons;
  const appsRef = useRef(apps); appsRef.current = apps;
  const selRef = useRef(sel); selRef.current = sel;
  const hSelRef = useRef(hSel); hSelRef.current = hSel;
  const overlayRef = useRef(overlay); overlayRef.current = overlay;
  const searchRef = useRef(searchOpen); searchRef.current = searchOpen;
  const menuRef = useRef(menuOpen); menuRef.current = menuOpen;
  const diagRef = useRef(diag); diagRef.current = diag;
  const dotsLp = useRef(null);
  const menuViewRef = useRef(menuView); menuViewRef.current = menuView;
  const saOpenRef = useRef(saOpen); saOpenRef.current = saOpen;
  const settingsRef = useRef(settings); settingsRef.current = settings;
  const sortOpenRef = useRef(sortOpen); sortOpenRef.current = sortOpen;
  const headRef = useRef(null);
  const head2Ref = useRef(null);
  const uninstQ = useRef([]);
  const searchInpRef = useRef(null);
  const mainPager = useRef(null);
  const mainTabs = useRef(null);
  const hidPager = useRef(null);
  const hidTabs = useRef(null);

  const loadDiag = async (q) => {
    try {
      const r = await Apps.settingsActivities({ q });
      setDiag({ q, list: r.list || [] });
    } catch (e) { say("Ошибка: " + (e.message || e)); }
  };

  const say = (msg) => { setToast(msg); clearTimeout(toastT.current); toastT.current = setTimeout(() => setToast(null), 2600); };

  const refresh = async () => {
    try {
      const r = await Apps.listApps();
      const list = (r.apps || []); // порядок задаёт выбранная сортировка (см. cmp)
      setApps(list);
      ls.set(LKEY, JSON.stringify(list));
      const need = list.filter((a) => { const ic = iconsRef.current[a.pkg]; const key = a.up || a.vc; return !ic || ic.v !== key; });
      if (need.length) {
        const rr = await Apps.ensureIcons({ items: need.map((a) => ({ p: a.pkg, v: a.up || a.vc })) });
        const got = rr.icons || {};
        const next = { ...iconsRef.current };
        for (const a of need) if (got[a.pkg]) next[a.pkg] = { v: a.up || a.vc, f: got[a.pkg] };
        setIcons(next);
        ls.set(IKEY, JSON.stringify(next));
      }
      return list;
    } catch (e) { say("Ошибка списка: " + (e.message || e)); return appsRef.current || []; }
  };

  /* ---- очередь массового удаления: следующий системный диалог после возврата в приложение ---- */
  const pumpUninstall = (list) => {
    const q_ = uninstQ.current;
    while (q_.length) {
      const pkg = q_.shift();
      if ((list || []).some((a) => a.pkg === pkg)) {
        try { Apps.uninstall({ pkg }); } catch {}
        return;
      }
    }
  };

  useEffect(() => {
    try { applyTheme(); } catch {} // повторно после готовности моста — системные панели под сохранённую тему
    refresh();
    let sub, back;
    (async () => {
      sub = await CapApp.addListener("resume", async () => {
        const list = await refresh();
        pumpUninstall(list);
      });
    })();
    (async () => {
      back = await CapApp.addListener("backButton", () => {
        if (diagRef.current) { setDiag(null); return; }
        if (sortOpenRef.current) { setSortOpen(false); return; }
        if (settingsRef.current === "theme") { setSettings("root"); return; }
        if (settingsRef.current) { setSettings(null); return; }
        if (saOpenRef.current) { setSaOpen(false); setMenuOpen(true); setMenuView("root"); return; }
        if (menuRef.current) { if (menuViewRef.current !== "root") setMenuView("root"); else setMenuOpen(false); return; }
        if (searchRef.current) { setSearchOpen(false); setQ(""); return; }
        if (hSelRef.current) { setHSel(null); return; }
        if (overlayRef.current) { setOverlay(null); return; }
        if (selRef.current) { setSel(null); return; }
        CapApp.minimizeApp();
      });
    })();
    return () => { sub && sub.remove(); back && back.remove(); };
  }, []);

  /* ---- сортировка: латиница сверху, кириллица после ---- */
  const grp = (s0) => {
    const c = (s0 || "").trim().charAt(0);
    if (!c) return 3;
    if (/[0-9]/.test(c)) return 0;
    if (/[A-Za-z]/.test(c)) return 1;
    if (/[А-Яа-яЁё]/.test(c)) return 2;
    return 3;
  };
  const cmp = useMemo(() => {
    if (sortBy === "size") return (a, b) => (b.size || 0) - (a.size || 0);
    if (sortBy === "date") return (a, b) => (b.up || 0) - (a.up || 0);
    return (a, b) => (grp(a.label) - grp(b.label)) || a.label.localeCompare(b.label, "en", { sensitivity: "base", numeric: true });
  }, [sortBy]);
  const srt = (arr) => arr.slice().sort(cmp);

  const hiddenSet = useMemo(() => new Set(hidden), [hidden]);
  const ql = q.trim().toLowerCase();
  const match = (a) => !ql || a.label.toLowerCase().includes(ql) || a.pkg.toLowerCase().includes(ql);
  const user = useMemo(() => srt((apps || []).filter((a) => !a.sys && !hiddenSet.has(a.pkg))), [apps, hiddenSet, cmp]);
  const sys = useMemo(() => srt((apps || []).filter((a) => a.sys && !hiddenSet.has(a.pkg))), [apps, hiddenSet, cmp]);
  const hUser = useMemo(() => srt((apps || []).filter((a) => !a.sys && hiddenSet.has(a.pkg))), [apps, hiddenSet, cmp]);
  const dUser = useMemo(() => srt((apps || []).filter((a) => !a.sys && a.en === false)), [apps, cmp]);
  const dSys = useMemo(() => srt((apps || []).filter((a) => a.sys && a.en === false)), [apps, cmp]);
  const hSys = useMemo(() => srt((apps || []).filter((a) => a.sys && hiddenSet.has(a.pkg))), [apps, hiddenSet, cmp]);

  /* ---- действия ---- */
  const doExtract = async (a) => {
    buzz(10);
    setBusy(a.split ? "Извлекаю APKS…" : "Извлекаю APK…");
    try {
      const r = await Apps.extractApk({ pkg: a.pkg });
      say("Извлечено: " + r.path);
    } catch (e) { say("Ошибка: " + (e.message || e)); }
    setBusy(null);
  };
  const doShare = async (a) => {
    buzz(10);
    setBusy("Готовлю файл…");
    try { await Apps.shareApk({ pkg: a.pkg }); } catch (e) { say("Ошибка: " + (e.message || e)); }
    setBusy(null);
  };
  const doUninstall = (a) => {
    buzz(10);
    try { Apps.uninstall({ pkg: a.pkg }); } catch (e) { say("Ошибка: " + (e.message || e)); }
  };
  const doAppInfo = (a) => {
    try { Apps.appSettings({ pkg: a.pkg }); } catch (e) { say("Ошибка: " + (e.message || e)); }
  };

  const setSaved = (next) => { setHidden(next); ls.set(HKEY, JSON.stringify(next)); };

  const pkgsOf = (ref) => (appsRef.current || []).filter((a) => ref.current && ref.current.has(a.pkg));
  const massExtract = async (ref, clear) => {
    const list = pkgsOf(ref);
    clear(null);
    let ok = 0, fail = 0;
    for (let i = 0; i < list.length; i++) {
      setBusy("Извлекаю " + (i + 1) + "/" + list.length + "…");
      try { await Apps.extractApk({ pkg: list[i].pkg }); ok++; } catch { fail++; }
    }
    setBusy(null);
    say("Извлечено: " + ok + (fail ? ", ошибок: " + fail : "") + " — папка Download");
  };
  const massShare = async (ref, clear) => {
    const pkgs = pkgsOf(ref).map((a) => a.pkg);
    clear(null);
    setBusy("Готовлю файлы…");
    try { await Apps.shareApks({ pkgs }); } catch (e) { say("Ошибка: " + (e.message || e)); }
    setBusy(null);
  };
  const massHide = () => {
    const pkgs = [...(selRef.current || [])];
    setSaved([...new Set([...hidden, ...pkgs])]);
    setSel(null);
    say("Скрыто из списка: " + pkgs.length);
  };
  const massUnhide = () => {
    const pkgs = new Set(hSelRef.current || []);
    const next = hidden.filter((p) => !pkgs.has(p));
    setSaved(next);
    setHSel(null);
    say("Возвращено в список: " + pkgs.size);
    if (next.length === 0) setOverlay(null);
  };
  const massUninstall = (ref, clear) => {
    uninstQ.current = pkgsOf(ref).map((a) => a.pkg);
    clear(null);
    pumpUninstall(appsRef.current || []);
  };

  const toggleSel = (pkg) => {
    const next = new Set(selRef.current || []);
    if (next.has(pkg)) next.delete(pkg); else next.add(pkg);
    setSel(next.size ? next : null);
  };
  const startSel = (pkg) => { buzz(20); setSel(new Set([pkg])); };
  const toggleHSel = (pkg) => {
    const next = new Set(hSelRef.current || []);
    if (next.has(pkg)) next.delete(pkg); else next.add(pkg);
    setHSel(next.size ? next : null);
  };
  const startHSel = (pkg) => { buzz(20); setHSel(new Set([pkg])); };

  const renderPanel = (list, selState, selR, onToggle, onStart, useMatch, hv) => (
    <div style={{ width: "50%", height: "100%", overflowY: "auto", touchAction: "pan-y", padding: `calc(var(${hv || "--hh"}, 110px) + 14px) 8px calc(90px + env(safe-area-inset-bottom))`, boxSizing: "border-box" }}>
      {apps === null && <div style={{ textAlign: "center", color: C.sub, marginTop: 60 }}>Загрузка…</div>}
      {apps !== null && list.length === 0 && <div style={{ textAlign: "center", color: C.sub, marginTop: 60 }}>Пусто</div>}
      {(useMatch ? list.filter(match) : list).map((a) => (
        <Row key={a.pkg} a={a} icSrc={icons[a.pkg] ? Capacitor.convertFileSrc(icons[a.pkg].f) : null}
          inSel={!!selState} checked={!!selState && selState.has(a.pkg)}
          onToggle={onToggle} onStartSel={onStart} selRef={selR}
          onExtract={doExtract} onShare={doShare} onUninstall={doUninstall} onIconClick={doAppInfo} theme={theme} />
      ))}
    </div>
  );

  // высота шапок пишется в CSS-переменные: при крупном системном шрифте шапка выше — список сам опускается
  const measureHeads = () => {
    for (const [ref, v] of [[headRef, "--hh"], [head2Ref, "--hh2"]]) {
      const el = ref.current;
      if (el) document.documentElement.style.setProperty(v, Math.round(el.getBoundingClientRect().bottom) + "px"); // bottom = безопасная зона + высота шапки
    }
  };
  useEffect(() => { measureHeads(); }); // каждый рендер — дёшево, без аллокаций
  useEffect(() => {
    measureHeads();
    let ro;
    try {
      ro = new ResizeObserver(measureHeads);
      for (const ref of [headRef, head2Ref]) if (ref.current) ro.observe(ref.current);
    } catch {}
    window.addEventListener("resize", measureHeads);
    return () => { try { ro && ro.disconnect(); } catch {} window.removeEventListener("resize", measureHeads); };
  }, [overlay, sel, hSel, apps === null]);

  const gotoMain = (i) => { buzz(5); mainPager.current && mainPager.current.snapTo(i); };
  const gotoHid = (i) => { buzz(5); hidPager.current && hidPager.current.snapTo(i); };

  const selCount = sel ? sel.size : 0;
  const hSelCount = hSel ? hSel.size : 0;
  const toolbarVisible = (overlay && hSel) || (!overlay && sel);

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, color: C.txt, fontFamily: "system-ui, sans-serif" }}>
      {/* ===== ГЛАВНЫЙ ЭКРАН ===== */}
      <Pager ctlRef={mainPager} onFrac={(f) => mainTabs.current && mainTabs.current.paint(f)}>
        {renderPanel(user, sel, selRef, toggleSel, startSel, true)}
        {renderPanel(sys, sel, selRef, toggleSel, startSel, true)}
      </Pager>

      <div ref={headRef} style={{ position: "fixed", left: 8, right: 8, top: "calc(8px + env(safe-area-inset-top))", zIndex: 50, background: C.bar, borderRadius: 20, boxShadow: C.barsh, padding: "10px 12px 10px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, minHeight: 32 }}>
          <span style={{ color: C.acc, display: "flex", flex: "0 0 auto" }}><Svg d={I.android} size={22} /></span>
          <span style={{ fontSize: 18, fontWeight: 700, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sel ? "Выбрано: " + selCount : "Apps"}</span>
          {!sel && <span style={{ fontSize: 11, color: C.sub, alignSelf: "flex-end", paddingBottom: 2, flex: "0 0 auto" }}>{APP_VERSION}</span>}
          {!sel && hidden.length > 0 && (
            <button onClick={() => { buzz(5); setOverlay('hidden'); }}
              style={{ flex: "0 0 auto", width: 32, height: 32, borderRadius: 16, border: "none", background: C.chip, color: C.sub, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
              <Svg d={I.eye} size={17} />
            </button>
          )}
          <button onClick={() => { buzz(5); setMenuView("root"); setMenuOpen(!menuRef.current); }}
            onTouchStart={() => { clearTimeout(dotsLp.current); dotsLp.current = setTimeout(() => { buzz(20); loadDiag("access"); }, 600); }}
            onTouchEnd={() => clearTimeout(dotsLp.current)}
            onTouchMove={() => clearTimeout(dotsLp.current)}
            onContextMenu={(e) => e.preventDefault()}
            style={{ marginLeft: "auto", flex: "0 0 auto", width: 32, height: 32, borderRadius: 16, border: "none", background: menuOpen ? C.accbg : C.chip, color: menuOpen ? C.acc : C.sub, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
            <Svg d={I.dots} size={18} />
          </button>
        </div>
        <TabBar ctlRef={mainTabs} labels={["Пользовательские", "Системные"]} counts={apps ? [user.length, sys.length] : null} onTap={gotoMain}
          onHold={() => { buzz(20); setSortOpen(true); }} />
      </div>

      {/* Контекстное меню системных экранов */}
      {menuOpen && (
        <div style={{ position: "fixed", inset: 0, zIndex: 75 }} onClick={() => setMenuOpen(false)}>
          <div onClick={(e) => e.stopPropagation()}
            style={{ position: "absolute", right: 12, top: "calc(52px + env(safe-area-inset-top))", background: C.bar, borderRadius: 16, boxShadow: C.barsh, padding: 6, minWidth: 250, maxWidth: "calc(100vw - 24px)", maxHeight: "70vh", overflowY: "auto" }}>
            {menuView === "root" && (
              <>
                <MenuBtn label="Специальный доступ" onClick={() => {
                  buzz(5);
                  setMenuOpen(false); setSaOpen(true); setSaList(null);
                  Apps.saItems().then((r) => setSaList(r.items || [])).catch((e) => { setSaList([]); say("Ошибка: " + (e.message || e)); });
                }} />
                <MenuBtn label="Приложения по умолчанию" onClick={async () => { setMenuOpen(false); buzz(5); try { await Apps.openScreen({ screen: "default_apps" }); } catch (e) { say("Ошибка: " + (e.message || e)); } }} />
                <MenuBtn label="Специальные возможности" onClick={async () => {
                  setMenuOpen(false); buzz(5);
                  try { await Apps.openScreen({ screen: "accessibility" }); } catch (e) { say("Ошибка: " + (e.message || e)); }
                }} />
                <MenuBtn label="Отключённые приложения" onClick={() => { setMenuOpen(false); buzz(5); setOverlay("disabled"); }} />
                <MenuBtn label="Настройки" onClick={() => { setMenuOpen(false); buzz(5); setSettings("root"); }} />
              </>
            )}
          </div>
        </div>
      )}

      {/* Отдельное подменю «Специальный доступ» */}
      {saOpen && (
        <div style={{ position: "fixed", inset: 0, zIndex: 76 }} onClick={() => setSaOpen(false)}>
          <div onClick={(e) => e.stopPropagation()}
            style={{ position: "absolute", right: 12, left: 12, top: "calc(52px + env(safe-area-inset-top))", background: C.bar, borderRadius: 16, boxShadow: C.barsh, padding: 6, maxHeight: "72vh", overflowY: "auto" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 8px 8px" }}>
              <button onClick={() => { setSaOpen(false); setMenuOpen(true); setMenuView("root"); }}
                style={{ width: 30, height: 30, borderRadius: 15, border: "none", background: C.chip, color: C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
                <Svg d={I.back} size={16} />
              </button>
              <span style={{ fontSize: 15, fontWeight: 700 }}>Специальный доступ</span>
            </div>
            {saList === null && <div style={{ fontSize: 13, color: C.sub, padding: "10px 14px" }}>Загрузка…</div>}
            {saList && saList.map((it) => (
              <MenuBtn key={it.action || it.cls} label={it.label} onClick={async () => {
                buzz(5); // подменю не закрываем: «Назад» из системного экрана вернёт сюда же
                try {
                  if (it.action) await Apps.openAction({ action: it.action });
                  else await Apps.launchSettingsActivity({ cls: it.cls });
                } catch (e) { say(e.message || String(e)); }
              }} />
            ))}
            {saList && saList.length === 0 && <div style={{ fontSize: 13, color: C.sub, padding: "10px 14px" }}>Ничего не открывается на этой прошивке</div>}
          </div>
        </div>
      )}

      {/* Меню сортировки (удержание заголовка вкладки) */}
      {sortOpen && (
        <div style={{ position: "fixed", inset: 0, zIndex: 130, background: "rgba(0,0,0,.35)", display: "flex", alignItems: "flex-start", justifyContent: "center" }} onClick={() => setSortOpen(false)}>
          <div onClick={(e) => e.stopPropagation()}
            style={{ marginTop: "calc(var(--hh, 110px) + 10px)", background: C.bar, borderRadius: 16, boxShadow: C.barsh, padding: 6, minWidth: 240, maxWidth: "calc(100vw - 32px)" }}>
            <div style={{ fontSize: 12, color: C.sub, padding: "8px 14px 4px" }}>Сортировка</div>
            {[["name", "По имени (A→Я)"], ["size", "По размеру"], ["date", "По дате обновления"]].map(([id, label]) => (
              <button key={id} onClick={() => { setSortBy(id); ls.set(SKEY, id); setSortOpen(false); buzz(5); }}
                style={{ display: "flex", alignItems: "center", gap: 10, width: "100%", textAlign: "left", border: "none", background: sortBy === id ? C.accbg : "transparent", color: C.txt, fontSize: 14.5, padding: "12px 14px", borderRadius: 11 }}>
                <span style={{ flex: 1, minWidth: 0 }}>{label}</span>
                {sortBy === id && <span style={{ color: C.acc, display: "flex", flex: "0 0 auto" }}><Svg d={I.check} size={16} /></span>}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ===== НАСТРОЙКИ ===== */}
      {settings && (
        <div style={{ position: "fixed", inset: 0, zIndex: 110, background: C.bg, display: "flex", flexDirection: "column" }}>
          <div style={{ flex: "0 0 auto", background: C.bar, boxShadow: C.barsh, paddingTop: "env(safe-area-inset-top)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", minHeight: 44 }}>
              <button onClick={() => { if (settings === "theme") setSettings("root"); else setSettings(null); }}
                style={{ flex: "0 0 auto", width: 32, height: 32, borderRadius: 16, border: "none", background: C.chip, color: C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
                <Svg d={I.back} size={17} />
              </button>
              <span style={{ fontSize: 18, fontWeight: 700, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{settings === "theme" ? "Тема" : "Настройки"}</span>
            </div>
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px calc(16px + env(safe-area-inset-bottom))" }}>
            {settings === "root" && (
              <>
                <button onClick={() => { buzz(5); setSettings("theme"); }}
                  style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left", border: "none", background: C.bar, color: C.txt, borderRadius: 16, padding: "14px 14px", marginBottom: 8 }}>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ display: "block", fontSize: 15, fontWeight: 600 }}>Тема</span>
                    <span style={{ display: "block", fontSize: 12.5, color: C.sub, marginTop: 2 }}>{theme === "system" ? "Системная" : (THEME_BY[theme] || THEME_BY.dark).name}</span>
                  </span>
                  <span style={{ color: C.sub, flex: "0 0 auto", transform: "rotate(180deg)", display: "flex" }}><Svg d={I.back} size={16} /></span>
                </button>
                <div style={{ fontSize: 12.5, color: C.sub, padding: "6px 4px" }}>Сортировка списка — удержание заголовка вкладки.</div>
              </>
            )}

            {settings === "theme" && (
              <>
                <button onClick={() => { setTheme("system"); ls.set(TKEY, "system"); applyTheme("system"); buzz(5); }}
                  style={{ display: "flex", alignItems: "center", width: "100%", textAlign: "left", border: "1.5px solid " + (theme === "system" ? C.acc : C.line), background: C.bar, color: C.txt, borderRadius: 14, padding: "13px 14px", marginBottom: 12 }}>
                  <span style={{ flex: 1, minWidth: 0, fontSize: 15 }}>Системная (как на телефоне)</span>
                  {theme === "system" && <span style={{ color: C.acc, display: "flex", flex: "0 0 auto" }}><Svg d={I.check} size={17} /></span>}
                </button>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
                  {THEMES.map((t) => {
                    const on = theme === t.id;
                    const tAccOn = ((0.299 * parseInt(t.acc.slice(1, 3), 16) + 0.587 * parseInt(t.acc.slice(3, 5), 16) + 0.114 * parseInt(t.acc.slice(5, 7), 16)) > 160) ? "#10100E" : "#FFFFFF";
                    return (
                      <div key={t.id} onClick={() => { setTheme(t.id); ls.set(TKEY, t.id); applyTheme(t.id); buzz(5); }}
                        style={{ borderRadius: 14, overflow: "hidden", border: on ? "2.5px solid " + t.acc : "1px solid " + t.border, background: t.card }}>
                        <div style={{ background: t.bg, padding: "10px 9px", display: "flex", flexDirection: "column", gap: 7 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                            <div style={{ flex: 1, height: 16, borderRadius: 8, background: t.acc, display: "flex", alignItems: "center", justifyContent: "center" }}>
                              <div style={{ width: "55%", height: 4, borderRadius: 2, background: tAccOn, opacity: 0.85 }} />
                            </div>
                            <div style={{ flex: 1, height: 16, borderRadius: 8, background: t.bar, display: "flex", alignItems: "center", justifyContent: "center" }}>
                              <div style={{ width: "55%", height: 4, borderRadius: 2, background: t.sub }} />
                            </div>
                          </div>
                          <div style={{ display: "flex", alignItems: "center", gap: 7, background: t.bar, borderRadius: 10, padding: "7px 8px" }}>
                            <div style={{ width: 22, height: 22, borderRadius: 6, background: t.acc, flexShrink: 0 }} />
                            <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
                              <div style={{ height: 5, width: "72%", borderRadius: 3, background: t.text, opacity: 0.85 }} />
                              <div style={{ height: 4, width: "45%", borderRadius: 3, background: t.sub }} />
                            </div>
                            <div style={{ width: 12, height: 12, borderRadius: 6, background: t.acc, opacity: 0.55, flexShrink: 0 }} />
                          </div>
                        </div>
                        <div style={{ background: t.bar, padding: "8px 10px", display: "flex", alignItems: "center", gap: 6, borderTop: "1px solid " + t.border }}>
                          <span style={{ color: t.text, fontSize: 13, fontWeight: 600, flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.name}</span>
                          {on && <span style={{ color: t.acc, display: "flex", flex: "0 0 auto" }}><Svg d={I.check} size={15} /></span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ===== ОВЕРЛЕЙ: СКРЫТЫЕ / ОТКЛЮЧЁННЫЕ ===== */}
      {overlay && (
        <div style={{ position: "fixed", inset: 0, zIndex: 80, background: C.bg }}>
          <Pager key={overlay} ctlRef={hidPager} onFrac={(f) => hidTabs.current && hidTabs.current.paint(f)}>
            {renderPanel(overlay === "hidden" ? hUser : dUser, hSel, hSelRef, toggleHSel, startHSel, false, "--hh2")}
            {renderPanel(overlay === "hidden" ? hSys : dSys, hSel, hSelRef, toggleHSel, startHSel, false, "--hh2")}
          </Pager>
          <div ref={head2Ref} style={{ position: "fixed", left: 8, right: 8, top: "calc(8px + env(safe-area-inset-top))", zIndex: 90, background: C.bar, borderRadius: 20, boxShadow: C.barsh, padding: "10px 12px 10px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, minHeight: 32 }}>
              <button onClick={() => { setHSel(null); setOverlay(null); }}
                style={{ flex: "0 0 auto", width: 32, height: 32, borderRadius: 16, border: "none", background: C.chip, color: C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
                <Svg d={I.back} size={17} />
              </button>
              <span style={{ fontSize: 18, fontWeight: 700, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{hSel ? "Выбрано: " + hSelCount : overlay === "hidden" ? "Скрытые" : "Отключённые"}</span>
              <span style={{ marginLeft: "auto", flex: "0 0 auto", color: C.sub, display: "flex" }}><Svg d={overlay === "hidden" ? I.hide : I.x} size={18} /></span>
            </div>
            <TabBar ctlRef={hidTabs} labels={["Пользовательские", "Системные"]}
              counts={overlay === "hidden" ? [hUser.length, hSys.length] : [dUser.length, dSys.length]} onTap={gotoHid}
              onHold={() => { buzz(20); setSortOpen(true); }} />
          </div>
        </div>
      )}

      {/* Лупа — правый нижний угол */}
      {!sel && !searchOpen && !overlay && (
        <button onClick={() => { setSearchOpen(true); buzz(5); setTimeout(() => searchInpRef.current && searchInpRef.current.focus(), 50); }}
          style={{ position: "fixed", right: 16, bottom: "calc(20px + env(safe-area-inset-bottom))", zIndex: 60, width: 56, height: 56, borderRadius: 28, border: "none", background: C.fab, color: C.onFab, boxShadow: C.barsh, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Svg d={I.search} size={24} />
        </button>
      )}

      {/* Строка поиска */}
      {searchOpen && (
        <div style={{ position: "fixed", left: 8, right: 8, bottom: "calc(12px + env(safe-area-inset-bottom))", zIndex: 70, background: C.bar, borderRadius: 18, boxShadow: C.barsh, display: "flex", alignItems: "center", gap: 8, padding: "8px 12px" }}>
          <span style={{ color: C.sub, display: "flex" }}><Svg d={I.search} size={18} /></span>
          <input ref={searchInpRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию или пакету"
            style={{ flex: 1, border: "none", outline: "none", background: "transparent", color: C.txt, fontSize: 15 }} />
          <button onClick={() => { setSearchOpen(false); setQ(""); }}
            style={{ width: 32, height: 32, borderRadius: 16, border: "none", background: C.chip, color: C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
            <Svg d={I.x} size={16} />
          </button>
        </div>
      )}

      {/* Панель действий выделения: справа налево — отмена, удалить, поделиться, извлечь, скрыть/отобразить */}
      {toolbarVisible && (
        <div style={{ position: "fixed", left: 8, right: 8, bottom: "calc(12px + env(safe-area-inset-bottom))", zIndex: 95, background: C.bar, borderRadius: 18, boxShadow: C.barsh, display: "flex", alignItems: "center", justifyContent: "space-evenly", padding: "8px 6px" }}>
          {overlay ? (
            <>
              {overlay === "hidden" && <SelBtn icon={I.eye} onClick={massUnhide} />}
              <SelBtn icon={I.dl} color={C.acc} onClick={() => massExtract(hSelRef, setHSel)} />
              <SelBtn icon={I.share} onClick={() => massShare(hSelRef, setHSel)} />
              <SelBtn icon={I.trash} color={C.red} onClick={() => massUninstall(hSelRef, setHSel)} />
              <SelBtn icon={I.x} onClick={() => setHSel(null)} />
            </>
          ) : (
            <>
              <SelBtn icon={I.hide} onClick={massHide} />
              <SelBtn icon={I.dl} color={C.acc} onClick={() => massExtract(selRef, setSel)} />
              <SelBtn icon={I.share} onClick={() => massShare(selRef, setSel)} />
              <SelBtn icon={I.trash} color={C.red} onClick={() => massUninstall(selRef, setSel)} />
              <SelBtn icon={I.x} onClick={() => setSel(null)} />
            </>
          )}
        </div>
      )}

      {/* Диагностика экранов настроек (долгий тап по троеточию) */}
      {diag && (
        <div style={{ position: "fixed", inset: 0, zIndex: 120, background: C.bg, display: "flex", flexDirection: "column", padding: "calc(10px + env(safe-area-inset-top)) 10px calc(10px + env(safe-area-inset-bottom))" }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
            <input value={diag.q} onChange={(e) => loadDiag(e.target.value)} placeholder="фильтр (например access)"
              style={{ flex: 1, border: "none", outline: "none", background: C.bar, color: C.txt, fontSize: 14, borderRadius: 12, padding: "10px 12px" }} />
            <button onClick={() => setDiag(null)}
              style={{ width: 38, height: 38, borderRadius: 19, border: "none", background: C.chip, color: C.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
              <Svg d={I.x} size={18} />
            </button>
          </div>
          <div style={{ fontSize: 12, color: C.sub, marginBottom: 6 }}>Экраны Настроек ({diag.list.length}). Тап — открыть; найдёшь нужный — пришли мне его имя.</div>
          <div style={{ flex: 1, overflowY: "auto" }}>
            {diag.list.map((cls) => (
              <button key={cls}
                onClick={async () => { try { await Apps.launchSettingsActivity({ cls }); } catch (e) { say(e.message || String(e)); } }}
                style={{ display: "block", width: "100%", textAlign: "left", border: "none", background: C.bar, color: C.txt, fontSize: 12, padding: "10px 12px", borderRadius: 12, marginBottom: 5, wordBreak: "break-all" }}>
                {cls.replace("com.android.settings|com.android.settings.", "").replace("|", " | ")}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Оверлей занятости */}
      {busy && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1300, background: "rgba(0,0,0,.45)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ background: C.bar, borderRadius: 18, boxShadow: C.barsh, padding: "18px 24px", display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ width: 20, height: 20, border: "3px solid " + C.line, borderTopColor: C.acc, borderRadius: "50%", animation: "maspin .8s linear infinite", display: "inline-block" }} />
            <span style={{ fontSize: 15 }}>{busy}</span>
          </div>
        </div>
      )}

      {/* Тост */}
      {toast && (
        <div style={{ position: "fixed", left: 16, right: 16, bottom: "calc(84px + env(safe-area-inset-bottom))", zIndex: 1500, display: "flex", justifyContent: "center", pointerEvents: "none" }}>
          <div style={{ background: C.row2, color: C.txt, borderRadius: 14, boxShadow: C.barsh, padding: "10px 16px", fontSize: 14, maxWidth: "100%", overflow: "hidden", textOverflow: "ellipsis" }}>{toast}</div>
        </div>
      )}

      <style>{"@keyframes maspin{to{transform:rotate(360deg)}}" +
        "body{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}" +
        "input{-webkit-user-select:text;user-select:text}"}</style>
    </div>
  );
}
